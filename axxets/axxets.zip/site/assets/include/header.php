<header id="tbay-header" class="site-header hidden-md hidden-sm hidden-xs main-sticky-header">
   <div class="top-bar">
      <div class="container">
         <div class="row">
            <div class="col-md-7">
               <div class="tbay-addon tbay-addon-social ">
                  <div class="tbay-addon-content">
                     <ul class="social list-inline style2">
                        <li>
                           <a target="_blank" href="#" class="facebook"><i class="linear-icon-telephone"></i> </a>
                        </li>
                        <li style="color:#fff;">
                           +91 9028388889, +91 9572852742
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="col-md-5 header-right">
               <div class="tbay-addon tbay-addon-social ">
                  <div class="tbay-addon-content">
                     <ul class="social list-inline style2">
                        <li>
                           <a target="_blank" href="#" class="facebook"><i class="zmdi zmdi-facebook"></i></a>
                        </li>
                        <li>
                           <a target="_blank" href="#" class="twitter"><i class="zmdi zmdi-twitter"></i></a>
                        </li>
                        <li>
                           <a target="_blank" href="#" class="youtube-play"><i class="zmdi zmdi-youtube-play"></i></a>
                        </li>
                        <li>
                           <a target="_blank" href="#" class="instagram"><i class="zmdi zmdi-instagram"></i></a>
                        </li>
                        <li>
                           <a target="_blank" href="#" class="pinterest"><i class="zmdi zmdi-pinterest"></i></a>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="header-main">
      <div class="container">
         <div class="row">
            <div class="header-logo col-md-4">
               <div class="logo logo-theme">
                  <a href="index.html">
                  <img class="header-logo-img" src="wp-content/themes/urna/images/toy/logo.png" alt="logo">
                  </a>
               </div>
            </div>
            <!-- //LOGO -->
            <div class="tbay-mainmenu col-md-6">
               <nav data-duration="400" class="menu hidden-xs hidden-sm tbay-megamenu slide animate navbar">
                  <div class="collapse navbar-collapse">
                     <ul id="primary-menu" class="nav navbar-nav megamenu" data-id="main-menu">
                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-110 current_page_item active menu-item-3938 level-0  active   active active  active  active  aligned-left">
                           <a class="elementor-item" href="index.php">Home</a>
                        </li>
                        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5262 level-0 active-mega-menu aligned-fullwidth">
                           <a class="elementor-item" href="#">About Us <b class="caret"></b></a>
                        </li>
                        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3900 level-0 active-mega-menu aligned-fullwidth">
                           <a class="elementor-item" href="#">Products <b class="caret"></b></a>
                        </li>
                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4048 level-0 active-mega-menu aligned-left">
                           <a class="elementor-item" href="contact.php">Contact us </a>
                        </li>
                     </ul>
                  </div>
               </nav>
            </div>
            <div class="header-right col-md-2">
               <!-- Search -->
               <!-- My-account -->
               <div class="tbay-login">
                  <a  data-toggle=modal data-target=#custom-login-wrapper href="#custom-login-wrapper" title="Login or Register">Login<span>Login or Register</span></a>          	
               </div>
            </div>
         </div>
      </div>
   </div>
   <div id="nav-cover"></div>
</header>