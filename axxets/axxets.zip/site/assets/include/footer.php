<footer id="tbay-footer" class="tbay-footer">
   <div class="footer">
      <div class="container">
         <p>
         <div class="vc_row wpb_row vc_row-fluid">
            <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-4">
               <div class="vc_column-inner">
                  <div class="wpb_wrapper">
                     <div class="tbay-addon tbay-addon-newsletter ">
                        <h3 class="tbay-addon-title">
                           SUBSCRIBE TO OUR NEWSLETTER
                        </h3>
                        <div class="tbay-addon-content">
                           <script>
                              (function() {
                                 window.mc4wp = window.mc4wp || {
                                    listeners: [],
                                    forms: {
                                       on: function(evt, cb) {
                                          window.mc4wp.listeners.push({
                                             event: evt,
                                             callback: cb
                                          });
                                       }
                                    }
                                 }
                              })();
                           </script><!-- Mailchimp for WordPress v4.8.6 - https://wordpress.org/plugins/mailchimp-for-wp/ -->
                           <form id="mc4wp-form-2" class="mc4wp-form mc4wp-form-227" method="post" data-id="227" data-name="newletters">
                              <div class="mc4wp-form-fields">
                                 <div class="mail-style1">
                                    <div class="input-group">
                                       <input id="mc4wp_email" class="form-control input-newletter" name="EMAIL" required="required" type="email" placeholder="Enter your email..." />
                                       <span class="input-group-btn">
                                          <input class="btn btn-default" type="submit" value="subscribe" />
                                       </span>
                                    </div>
                                 </div>
                              </div>
                              <label style="display: none !important;">Leave this field empty if you're human: <input type="text" name="_mc4wp_honeypot" value="" tabindex="-1" autocomplete="off" /></label><input type="hidden" name="_mc4wp_timestamp" value="1626399510" /><input type="hidden" name="_mc4wp_form_id" value="227" /><input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-2" />
                              <div class="mc4wp-response"></div>
                           </form>
                           <!-- / Mailchimp for WordPress Plugin -->
                        </div>
                     </div>
                     <div class="tbay-addon tbay-addon-text-heading  ">
                        <h3 class="tbay-addon-title">
                           <span>CONTACT US:</span>
                        </h3>
                     </div>
                     <div class="wpb_text_column wpb_content_element ">
                        <div class="wpb_wrapper">
                           <ul class="contact-info">
                              <li style="list-style-type: none;">
                                 <ul class="contact-info">
                                    <li class="contact"><i class="linear-icon-telephone"></i><span class="text-white"> Contact 24/7:</span> <a href="tel:(+1)180078964185">+91 9028388889 | +91 9572852742</a></li>
                                    <li class="address"><i class="linear-icon-map-marker"></i> <span class="text-white">Address: </span> Janki Market, Bhagwat Nagar.
                                    </li>
                                    <li><i class="linear-icon-envelope"></i><span class="text-white"> E-mail:</span> info@camwel.com</li>
                                 </ul>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="tbay-addon tbay-addon-social ">
                        <div class="tbay-addon-content">
                           <ul class="social list-inline style2">
                              <li>
                                 <a target="_blank" href="#" class="facebook"><i class="zmdi zmdi-facebook"></i></a>
                              </li>
                              <li>
                                 <a target="_blank" href="#" class="twitter"><i class="zmdi zmdi-twitter"></i></a>
                              </li>
                              <li>
                                 <a target="_blank" href="#" class="youtube-play"><i class="zmdi zmdi-youtube-play"></i></a>
                              </li>
                              <li>
                                 <a target="_blank" href="#" class="instagram"><i class="zmdi zmdi-instagram"></i></a>
                              </li>
                              <li>
                                 <a target="_blank" href="#" class="pinterest"><i class="zmdi zmdi-pinterest"></i></a>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-4">
               <div class="vc_column-inner">
                  <div class="wpb_wrapper">
                     <div class="tbay-addon tbay-addon-text-heading  ">
                        <h3 class="tbay-addon-title">
                           <span>DOWNLOAD APP</span>
                        </h3>
                     </div>
                     <div class="wpb_single_image tbay-addon wpb_content_element vc_align_left  vc_custom_1564383957205  app-footer">
                        <figure class="wpb_wrapper vc_figure">
                           <a href="#" target="_blank" class="vc_single_image-wrapper   vc_box_border_grey">
                              <img width="124" height="35" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20124%2035'%3E%3C/svg%3E" class="vc_single_image-img attachment-thumbnail" alt="" loading="lazy" data-lazy-src="wp-content/uploads/sites/4/2019/07/app-ios.png" />
                              <noscript><img width="124" height="35" src="wp-content/uploads/sites/4/2019/07/app-ios.png" class="vc_single_image-img attachment-thumbnail" alt="" loading="lazy" /></noscript>
                           </a>
                        </figure>
                     </div>
                     <div class="wpb_single_image tbay-addon wpb_content_element vc_align_left   app-footer">
                        <figure class="wpb_wrapper vc_figure">
                           <a href="#" target="_blank" class="vc_single_image-wrapper   vc_box_border_grey">
                              <img width="124" height="35" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20124%2035'%3E%3C/svg%3E" class="vc_single_image-img attachment-thumbnail" alt="" loading="lazy" data-lazy-src="wp-content/uploads/sites/4/2019/07/app-androids.png" />
                              <noscript><img width="124" height="35" src="wp-content/uploads/sites/4/2019/07/app-androids.png" class="vc_single_image-img attachment-thumbnail" alt="" loading="lazy" /></noscript>
                           </a>
                        </figure>
                     </div>
                     <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div class="wpb_column vc_column_container vc_col-sm-6">
                           <div class="vc_column-inner">
                              <div class="wpb_wrapper">
                                 <div class="tbay_custom_menu wpb_content_element  none-menu">
                                    <div class="tbay-addon tbay-addon-nav-menu">
                                       <h2 class="tbay-addon-title">YOUR ACCOUNT</h2>
                                       <div class="nav menu-category-menu-container">
                                          <ul id="menu-footer-1-vhxcB" class="menu">
                                             <li id="menu-item-7060" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7060 aligned-"><a class="elementor-item" href="my-account/index.html">Sign Up</a></li>
                                             <li id="menu-item-7061" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7061 aligned-"><a class="elementor-item" href="my-account/index.html">Login</a></li>
                                             <li id="menu-item-7063" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7063 aligned-"><a class="elementor-item" href="wishlist/index.html">Wishlist</a></li>
                                             <li id="menu-item-7062" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7062 aligned-"><a class="elementor-item" href="cart/index.html">Shopping cart</a></li>
                                          </ul>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-6">
                           <div class="vc_column-inner">
                              <div class="wpb_wrapper">
                                 <div class="tbay_custom_menu wpb_content_element  none-menu">
                                    <div class="tbay-addon tbay-addon-nav-menu">
                                       <h2 class="tbay-addon-title">DEPARTMENT</h2>
                                       <div class="nav menu-category-menu-container">
                                          <ul id="menu-footer-2-iAZke" class="menu">
                                             <li id="menu-item-7064" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7064 aligned-"><a class="elementor-item" href="#">Collection</a></li>
                                             <li id="menu-item-7065" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7065 aligned-"><a class="elementor-item" href="#">Categories</a></li>
                                             <li id="menu-item-7066" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7066 aligned-"><a class="elementor-item" href="#">What’s New Today</a></li>
                                             <li id="menu-item-7067" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7067 aligned-"><a class="elementor-item" href="#">Recommended</a></li>
                                          </ul>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-4">
               <div class="vc_column-inner">
                  <div class="wpb_wrapper">
                     <div class="tbay-addon tbay-addon-text-heading  ">
                        <h3 class="tbay-addon-title">
                           <span>ACCEPTED PAYMENT</span>
                        </h3>
                     </div>
                     <div class="wpb_single_image tbay-addon wpb_content_element vc_align_left  vc_custom_1564623110196  app-footer">
                        <figure class="wpb_wrapper vc_figure">
                           <a href="#" target="_blank" class="vc_single_image-wrapper   vc_box_border_grey">
                              <img width="212" height="35" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20212%2035'%3E%3C/svg%3E" class="vc_single_image-img attachment-thumbnail" alt="" loading="lazy" data-lazy-src="wp-content/uploads/sites/4/2019/07/payment.png" />
                              <noscript><img width="212" height="35" src="wp-content/uploads/sites/4/2019/07/payment.png" class="vc_single_image-img attachment-thumbnail" alt="" loading="lazy" /></noscript>
                           </a>
                        </figure>
                     </div>
                     <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div class="wpb_column vc_column_container vc_col-sm-6">
                           <div class="vc_column-inner">
                              <div class="wpb_wrapper">
                                 <div class="tbay_custom_menu wpb_content_element  none-menu">
                                    <div class="tbay-addon tbay-addon-nav-menu">
                                       <h2 class="tbay-addon-title">INFORMATION</h2>
                                       <div class="nav menu-category-menu-container">
                                          <ul id="menu-footer-3-Sx5VF" class="menu">
                                             <li id="menu-item-7068" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7068 aligned-"><a class="elementor-item" href="#">Help Center</a></li>
                                             <li id="menu-item-7069" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7069 aligned-"><a class="elementor-item" href="#">Feedback</a></li>
                                             <li id="menu-item-7071" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7071 aligned-"><a class="elementor-item" href="contact-us/index.html">Contact</a></li>
                                             <li id="menu-item-7070" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7070 aligned-"><a class="elementor-item" href="about-us/index.html">About Us</a></li>
                                          </ul>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-6">
                           <div class="vc_column-inner">
                              <div class="wpb_wrapper">
                                 <div class="tbay_custom_menu wpb_content_element  none-menu">
                                    <div class="tbay-addon tbay-addon-nav-menu">
                                       <h2 class="tbay-addon-title">COMMUNITY</h2>
                                       <div class="nav menu-category-menu-container">
                                          <ul id="menu-footer-4-8YNxJ" class="menu">
                                             <li id="menu-item-7072" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7072 aligned-"><a class="elementor-item" href="#">Blog</a></li>
                                             <li id="menu-item-7073" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7073 aligned-"><a class="elementor-item" href="#">Fanpages</a></li>
                                             <li id="menu-item-7074" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7074 aligned-"><a class="elementor-item" href="#">Event</a></li>
                                             <li id="menu-item-7075" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7075 aligned-"><a class="elementor-item" href="#">Hosting</a></li>
                                          </ul>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid tbay-copyright">
            <div class="wpb_column vc_column_container vc_col-sm-12">
               <div class="vc_column-inner">
                  <div class="wpb_wrapper">
                     <div class="wpb_text_column wpb_content_element ">
                        <div class="wpb_wrapper">
                           <p>© 2021 <a href="#"></a> by Camwel Corporate Solution Private Limited. All right reserved</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="vc_row-full-width vc_clearfix"></div>
         </p>
      </div>
   </div>
</footer>